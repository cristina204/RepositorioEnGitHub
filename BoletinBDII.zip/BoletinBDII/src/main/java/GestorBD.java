import java.sql.SQLException;
import java.sql.*;
import java.util.ArrayList;


public class GestorBD {
    public GestorBD() {
    }

    static Connection connection = null;

    public static boolean Conexion(){


        String dbUrl = "jdbc:mysql://127.0.0.1:3306/";
        String user = "root";
        String pwd = "abc123.";
        try {

            connection = DriverManager.getConnection(dbUrl, user, pwd);

            Statement stmt= connection.createStatement();
            stmt.execute("Create schema if not exists controlusuarios " +
                    "default char set utf8mb4 default collate utf8mb4_spanish_ci");

            System.out.println("Conexion realizada con exito");
            return true;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return false;
        }
    }
    public void CrearBaseDatos() {
        String db = "controlusuarios";
        try {
            if (Conexion() ) {
                connection.setCatalog(db);
                Statement stmt = connection.createStatement();
                stmt.execute("Create schema if not exists controlusuarios " +
                        "default char set utf8mb4 default collate utf8mb4_spanish_ci");
            }


        } catch (SQLException e) {
            System.err.println(e.getMessage());


        }
    }
    public void CrearTabla(){
        String db = "controlusuarios";
        try{
            if (Conexion()) {
                connection.setCatalog(db);
                String creatable=("Create table if not exists usuarios( email varchar(50) not null, password varchar(50) not null," +
                        " estado  varchar(10) not null, " +
                        "Rol   varchar(15) not null,	" +
                        "constraint pk_usuarios primary key(email))");
                PreparedStatement statement=connection.prepareStatement(creatable);
                statement.executeUpdate();
                statement.close();
            }

        }catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
    public void InsertaUsuarios(Usuario usuario){
        String db = "controlusuarios";
        PreparedStatement mysqlstatement=null;
        ResultSet mysqlresultset=null;
        if (Conexion()){
            String inserString="insert into usuarios (email,password,estado,Rol) values (?,?,?,?)";

            try{
                connection.setCatalog(db);
                mysqlstatement= connection.prepareStatement(inserString);
                mysqlstatement.setString(1, usuario.getEmail());
                mysqlstatement.setString(2, usuario.getPassword());
                mysqlstatement.setString(3,usuario.getEstado().name());
                mysqlstatement.setString(4,usuario.getRol().name());

                mysqlstatement.executeUpdate();

            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
    }
    public static ArrayList<Usuario> listar() {
        ArrayList<Usuario> usuario = new ArrayList<>();
        String db = "controlusuarios";
        PreparedStatement mysqlstatement=null;
        ResultSet mysqlresultset=null;
        try {
            connection.setCatalog(db);
            if (Conexion()) {
                mysqlstatement= (PreparedStatement) connection.createStatement();
                mysqlresultset=mysqlstatement.executeQuery("SELECT * FROM controlusuarios");

                while (mysqlresultset.next()){


                    Usuario usuarios=new Usuario(mysqlresultset.getString("email"),mysqlresultset.getString("password"),Estado.valueOf(mysqlresultset.getString("estado")), Rol.valueOf(mysqlresultset.getString("Rol") ));
                    listar().add(mysqlresultset.getInt(1),usuarios);
                }
            }

        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }finally{
            if (mysqlresultset!=null){
                try{
                    mysqlresultset.close();
                }catch  (SQLException e) {
                    System.err.println(e.getMessage());
                    return null;
                }
            }
            if (mysqlresultset!=null){
                try{
                    mysqlstatement.close();
                }catch  (SQLException e) {
                    System.err.println(e.getMessage());
                    return null;
                }
            }
            if (connection!=null){
                try{
                    connection.close();
                }catch (Exception e){
                    System.err.println(e.getMessage());

                }
            }

        }
        return usuario;
    }

    public static boolean ControlAcceso(String user,String password ){
        String db = "controlusuarios";
        PreparedStatement mysqlstatement=null;
        ResultSet mysqlresultset=null;
        try{
            connection.setCatalog(db);
            if (Conexion()){
                mysqlstatement= (PreparedStatement) connection.createStatement();
                ((PreparedStatement) mysqlstatement).setString(1,user);
                ((PreparedStatement) mysqlstatement).setString(2,password);
                mysqlresultset=mysqlstatement.executeQuery("SELECT COUNT(*) FROM usuarios where email=? and password=?");
                if (mysqlresultset.next()){
                    int cont=mysqlresultset.getInt(1);
                    if (cont == 0){
                        return false;
                    }else {
                        return true;
                    }
                }
                connection.close();
                mysqlresultset.close();
                mysqlstatement.close();
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return false;
    }

    public static void ActualizarContraseña(String usuario,String contraseña,String nuevaPass){
        String db = "controlusuarios";
        PreparedStatement mysqlstatement=null;
        ResultSet mysqlresultset=null;
        try{
            connection.setCatalog(db);
            if (Conexion()){
                mysqlstatement= (PreparedStatement) connection.createStatement();

                ((PreparedStatement) mysqlstatement).setString(1,nuevaPass);
                ((PreparedStatement) mysqlstatement).setString(2,usuario);
                ((PreparedStatement) mysqlstatement).setString(3,contraseña);
                int actualizacion=mysqlstatement.executeUpdate("update usuarios set password=? where email=? and password=?");
                connection.close();
                mysqlstatement.close();
            }
        }catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
    public static void BorrarUsuarios(String usuario,String contraseña){
        String db = "controlusuarios";
        PreparedStatement mysqlstatement=null;
        ResultSet mysqlresultset=null;
        try{
            connection.setCatalog(db);
            if (Conexion()){
                mysqlstatement= (PreparedStatement) connection.createStatement();

                ((PreparedStatement) mysqlstatement).setString(1,usuario);
                ((PreparedStatement) mysqlstatement).setString(2,contraseña);
                int eliminar=mysqlstatement.executeUpdate("update usuarios set password=? where email=? and password=?");
                connection.close();
                mysqlstatement.close();
            }
        }catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
}
