import Modelo.Estado;
import Modelo.Rol;
import Modelo.Usuario;

import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    static Scanner leer=new Scanner(System.in);
    public static void main(String[] args)  {
        GestorBD gestor =new GestorBD();
        Usuario user=new Usuario("cristina@gmail.com", "35611974Q0", Estado.ACTIVO, Rol.USUARIO);
        gestor.CrearBaseDatos();
        gestor.CrearTabla();
        gestor.InsertaUsuarios(user);
        gestor.listar();
        gestor.ControlAcceso();
        gestor.ActualizarContraseña();
        gestor.BorrarUsuarios();
    }
}
