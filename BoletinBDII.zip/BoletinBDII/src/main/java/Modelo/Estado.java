package Modelo;

public enum Estado {
    ACTIVO, INACTIVO
}
