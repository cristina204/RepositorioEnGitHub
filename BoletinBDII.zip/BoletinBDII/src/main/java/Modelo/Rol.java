package Modelo;

public enum Rol {
    ADMIN, INVITADO, USUARIO
}
