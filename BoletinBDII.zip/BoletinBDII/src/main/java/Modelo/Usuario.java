package Modelo;

import Modelo.Estado;
import Modelo.Rol;

public class Usuario {
    private String email;
    private String password;
    private Estado estado;
    private Rol rol;


    public Usuario() {
    }

    public Usuario(String email, String password, Estado estado, Rol rol) {
        this.email = email;
        this.password = password;
        this.estado = estado;
        this.rol = rol;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public Estado getEstado() {
        return estado;
    }

    public Rol getRol() {
        return rol;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }

    @Override
    public String toString() {
        return "Modelo.Usuario{" +
                "email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", estado=" + estado +
                ", rol=" + rol +
                '}';
    }
}
